#include<stdio.h>
#include<stdlib.h>

void merge(int *a,int low,int mid,int high)
{
	int h=low,i=low,j=mid+1,b[100],k;
	while((h<=mid) && (j<=high)) 
	{
		if(*(a+h)<=*(a+j))
		{
		b[i]=*(a+h);
		h=h+1;
		}
		else{
		b[i]=*(a+j);
		j=j+1;
		}
		i=i+1;
	}
	
	if(h>mid)
	{
		while(j<=high){
			b[i++]=*(a+j);
			j++;
		
		}
	}
	else
	{
			while(h<=mid)
			{
			b[i++]=*(a+h);
			h++;
			}
	}
	
	for(k=low;k<=high;k++)
	*(a+k)=b[k];
}
void merge_sort(int *a,int low,int high)
{
	int mid;
	if(low<high)
	{
		mid=(low+high)/2;
		merge_sort(a,low,mid);
		merge_sort(a,mid+1,high);
		merge(a,low,mid,high);
	}
}

		
int main(void)
{
	int *a,n,i;
	printf("Enter the no of elements::");
	scanf("%d",&n);
	a=(int *)malloc(n*(sizeof(int)));
	printf("Enter the elements in array::");
	for(i=0;i<n;i++)
		scanf("%d",(a+i));
		
	printf("Enter the elements in array::");
	for(i=0;i<n;i++)
		printf("%3d",a[i]);
	merge_sort(a,0,n-1);
	printf("The sorted array is\n");
	for(i=0;i<n;i++)
		printf("%d\n",a[i]);
		return 0;
}
	

	
