#include<stdio.h>
#include<stdlib.h>
int parent[100],cost[100][100],n;
int input()
{
	int i,j;
	FILE *fp;
	fp=fopen("graph.txt","r");
	if(fp==NULL)
	printf("Empty\n");
	else
	{
		fscanf(fp,"%d",&n);
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=n;j++)
				fscanf(fp,"%d",&cost[i][j]);
		}
	}
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		if(cost[i][j]==0 && i!=j)
		cost[i][j]=999;
	}
	for(i=1;i<=n;i++)
	{
			for(j=1;j<=n;j++)
			printf("%d ",cost[i][j]);
			printf("\n");
	}
	
}
int find(int i)
{
	while(parent[i])
	{
		i=parent[i];
	}
	return i;
}

int uni(int i,int j)
{
	if(i!=j)
	{
		parent[j]=i;
		return 1;
	}
	return 0;
}

void kruskal()
{
	int ne=1,i,j,min,a,u,v,b,mincost=0;
	while(ne<n)
	{
		min=999;
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=n;j++)
			{
				if(cost[i][j]<min)
				{
					min=cost[i][j];
					a=u=i;
					b=v=j;
				}
			}
		}
		u=find(u);
		v=find(v);
		if(uni(u,v))
		{
			printf("%d edge(%d;%d)=%d\n",ne++,a,b,min);
			mincost+=min;
		}
		cost[a][b]=cost[b][a]=999;
	}
	printf("\n\tMinimum cost::%d\n\n",mincost);
}
int main(void)
{
	input();
	kruskal();
}





