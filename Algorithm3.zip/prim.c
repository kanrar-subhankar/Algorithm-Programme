#include<stdio.h>
#include<stdlib.h>
int *key,tree[10][10],*visited,*parent,**a,nov,tree_edge=0;
int input()
{
	int s;
	printf("Enter the source::");
	scanf("%d",&s);
	key=(int *)malloc(sizeof(int)*(nov+1));
	visited=(int *)malloc(sizeof(int)*(nov+1));
	parent=(int *)malloc(sizeof(int)*(nov+1));	
	return s;
}
void file()
{
	FILE *fp;
	int i,j;
	fp=fopen("graph_prim.txt","r");
	fscanf(fp,"%d",&nov);
	a=(int **)malloc(sizeof(int *)*(nov+1));
	for (i = 1; i <= nov; i++)
		*(a+i) = (int *)malloc(sizeof(int)*(nov+1));
	for(i=1;i<=nov;i++)
	{
		for(j=1;j<=nov;j++)
			fscanf(fp,"%d",&a[i][j]);
	}
	for(i=1;i<=nov;i++){
		for(j=1;j<=nov;j++)
		printf("%d  ",a[i][j]);
		printf("\n");
	}
}
	

void initialize(int src)
{
	int i;
	for(i=1;i<=nov;i++)
	{
		key[i]=9999;
		parent[i]=0;
		visited[i]=0;
		tree[i][1]=tree[i][2]=i;
	}
	key[src]=0;
}

int extract_min()
{
	int min,i,x;
	min=9999;
	for(i=1;i<=nov;i++)
	{
		if(visited[i]!=1)
		{
			if(min>key[i])
			{
				min=key[i];
				x=i;
			}
		}
	}
	visited[x]=1;
	return x;
}

void prim(int src)
{
	int i,u,v;
	initialize(src);

	for(i=1;i<=nov;i++){
		u=extract_min();
		tree_edge++;
		tree[tree_edge][1]=parent[u];
		tree[tree_edge][2]=u;
		for(v=1;v<=nov;v++)
		{
			if(a[u][v]!=9999 && visited[v]==0)
			{
				if(key[v]>a[u][v])
				{
					key[v]=a[u][v];
					parent[v]=u;
				}
			}
		}
	}
}

int main(void)
{
	int s,i,j;
	s=input();
	file();
	initialize(s);
	prim(s);
	printf("The minimum spaining tree::");
	for(i=1;i<tree_edge;i++)
		printf("%d-------%d\n",tree[i][1],tree[i][2]);
	return 0;
}
	
	
		
		
		
		
		
		
		
		
