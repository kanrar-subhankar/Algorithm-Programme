#include<stdio.h>
#include<limits.h>
int dist[100],vis[100],v,n;
int dj(int cost[][100])
{
	int count,i,u;
	for(i=1;i<=n;i++)
	{
		vis[i]=0;
		dist[i]=cost[v][i];
	//dist[i]=INT_MAX;
	}
	
	count=1;
	while(count<=n)
	{
		int p,min=INT_MAX;
		for(i=1;i<=n;i++)
		{
			if(dist[i]<min && !vis[i])
			{
				min=dist[i];
				 u=i;
			}
		}
		printf("%d**\n",u);
	   /*	for(p=1;p<=n;p++)
		{
			printf("%d  ",dist[p]);
		}*/
		printf("\n");
		vis[u]=1;
		for(i=1;i<=n;i++)
		{
			if(dist[u]+cost[u][i]<dist[i] && !vis[i] && cost[u][i]!=INT_MAX )
			{
				dist[i]=dist[u]+cost[u][i];
			}
		}
		count++;
	}	
}

main()
{
	int cost[100][100],i,j,k,l;
	FILE *p1;
	p1=fopen("path.txt","r");
	fscanf(p1,"%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			fscanf(p1,"%d",&k);
			if(k==0 && i!=j)
			{
				cost[i][j]=INT_MAX;
			}
			else
			{
				cost[i][j]=k;
			}
		}
	}
	printf("Enter the starting node\n");
	scanf("%d",&v);
	dj(cost);
	for(i=1;i<=n;i++)
	{
		if(i!=v)
		{
		printf("%d dis is->%d\n",i,dist[i]);}
	}
}


