#include<stdio.h>
#include<stdlib.h>
void max_min(int *a,int lb,int ub,int *max,int *min)
{
	int max1,min1,mid;
	if(lb==ub){
		*max=*(a+lb);
		*min=*(a+lb);
	}
	else if(ub==lb+1)
	{
		if(*(a+lb)>*(a+ub))
		{
			*max=*(a+lb);
			*min=*(a+ub);
		}
		else
		{
			*min=*(a+lb);
			*max=*(a+ub);
		}
	}
	else
	{
		mid=(lb+ub)/2;
		max_min(a,lb,mid,max,min);
		max_min(a,mid+1,ub,&max1,&min1);
		if(max1>*max)
			*max=max1;
		if(min1<*min)
			*min=min1;
	}



}
int main(void)
{
	int i,n,max,min;
	int *a;
	printf("Enter the no of elements\n");
	scanf("%d",&n);
	a=(int *)malloc(n*sizeof(int));
	printf("Enter the values\n");
	for(i=0;i<n;i++)
	scanf("%d",(a+i));
	max_min(a,0,n-1,&max,&min);
	printf("The max value is::%d\n",max);
	printf("The min value is::%d\n",min);
	return 0;
}
	
