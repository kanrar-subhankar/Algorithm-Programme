#include<stdio.h>
#include<math.h>
int x[10];
int place(int k,int i)
{
	int j;
	for(j=1;j<=k-1;j++)
	{
		if((x[j]==i)|| (fabs(x[j]-i))==(fabs(j-k)))
		return 0;
	}
	return 1;
}
		
void N_Queen(int k,int n)
{
	int i,j;
	for(i=1;i<=n;i++)
	{
		if(place(k,i)){
		x[k]=i;
		if(k==n)
		{
			for(j=1;j<=n;j++)
			printf("%d\t",x[j]);
			printf("\n");
		}
		else
		N_Queen(k+1,n);
	}
	
	}
}
		
int main(void)
{
	int n,k,i;
	printf("Enter the no of queens::\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
	N_Queen(i,n);
	}
}
