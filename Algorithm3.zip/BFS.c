#include<stdio.h>
#include<stdlib.h>
#define NIL -1
int nov,**a,*d,*p,*q;
int head=0,tail=0;
char *color;
void f1()
{
	int i,j;
	FILE *fp;
	fp=fopen("graph.txt","r");
	if(fp==NULL)
		printf("\nFile Does Not Exist!!\n");
	else
	{
		fscanf(fp,"%d",&nov);
		a=(int **) malloc(nov*sizeof(int*));
		for(i=0;i<nov;i++)
			a[i]=(int *)malloc(nov*sizeof(int));
		for(i=0;i<nov;i++)
			for(j=0;j<nov;j++)
				fscanf(fp,"%d",&a[i][j]);
	}
		     for(i=0;i<nov;i++){
			for(j=0;j<nov;j++)
				printf(" %d",a[i][j]);
			printf("\n");
			}

}
void enqueue(int x)
{
	q[tail++]=x;
}
int dequeue()
{
	int x=q[head++];
	return x;
}
void BFS(int s)
{
	int v,u;
	for(u=0;u<nov;u++)
		if(u!=s)
		{
			color[u]='W';
			//d[u]=99999;
		 	p[u]=NIL;
		}
	color[s]='G';
	//d[s]=0;
	p[s]=NIL;
	q[0]=NIL;  
	enqueue(s);
	while(head!=tail)
	{
		u=dequeue();
		printf("%d->",u);
		for(v=0;v<nov;v++)
			if(a[u][v]==1)
				if(color[v]=='W')
				{
					color[v]='G';
					//d[v]=d[u]+1;
					p[v]=u;
					enqueue(v);
				}
		color[u]='B';
	}
}
int input()
{
	int s;
	printf("\nEnter the Source Node No. : ");
	scanf("%d",&s);
	color=(char *) malloc(nov*sizeof(char));
	d=(int *) malloc(nov*sizeof(int));
	p=(int *) malloc(nov*sizeof(int));
	q=(int *) malloc(nov*sizeof(int));
	return s;
}
void main()
{
	int s,i;
	f1();
	s=input();
	printf("%d\n\n\n",s);
	BFS(s);
	for(i=0;i<nov;i++)
		printf("\nParent of %d : %d ",i,p[i]);

}



