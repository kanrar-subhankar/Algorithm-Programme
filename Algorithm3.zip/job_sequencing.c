#include<stdio.h>
#include<stdlib.h>
struct job{
	int p,d;
}a[100];
int js(int n)
{
	int i,k,r,q,j[10];
	a[0].d=0;
	j[0]=0;
	j[1]=1;
	k=1;
	for(i=2;i<=n;i++)
	{
	r=k;
	//printf("%d\t%d\n",a[j[r]].d,a[i].d);
	while((a[j[r]].d>a[i].d) && (a[j[r]].d!=r))
		r=r-1;
	if((a[j[r]].d<=a[i].d) && (a[i].d>r))
	{
		for(q=k;q<=(r+1);q++){
			j[q+1]=j[q];
		//printf("%d\t%d\n",j[q+1],q+1);
			}
		j[r+1]=i;
		k++;
	}
	}
	printf("k=%d\n",k);
	printf("Job\tDeadLine\tProfit\n");
	for(i=1;i<=k;i++)
		printf("%d\t%d\t\t%d\n",j[i],a[j[i]].d,a[j[i]].p);
}

int main(void)
{
	int n,max,j,i;
	struct job temp;
	printf("Enter the no of jobs::");
	scanf("%d",&n);
	printf("Enter the job profit and deadline-->\n");
	for(i=1;i<=n;i++)
	scanf("%d%d",&a[i].p,&a[i].d);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++)
		{
			if(a[j].p<a[j+1].p){
			temp=a[j];
			a[j]=a[j+1];
			a[j+1]=temp;
			}
		}
	}
	printf("after sorting jobs are");
	for(i=1;i<=n;i++)
		printf("\njob=%d\tprofit=%d\tdeadline=%d\n",i,a[i].p,a[i].d);
	js(n);
	
	return 0;
}
	
	

		
	
