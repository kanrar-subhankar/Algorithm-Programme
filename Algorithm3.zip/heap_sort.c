#include<stdio.h>
#include<stdlib.h>
void max_heap(int a[],int n)
{
	int i;
	for(i=n/2;i>=1;i--)
	{
			if(a[2*i]>a[(2*i)+1])
			{
				if(a[2*i]>a[i])
				a[2*i]=(a[2*i]+a[i])-(a[i]=a[2*i]);
			}
			else
			{
				if(a[(2*i)+1]>a[i])
				a[(2*i)+1]=(a[(2*i)+1]+a[i])-(a[i]=a[(2*i)+1]);
			}
	
			if(a[2*i]>a[i])
			a[2*i]=(a[2*i]+a[i])-(a[i]=a[2*i]);
		
	}
	for(i=1;i<=n;i++)
	printf("%d\t",a[i]);
	printf("\n");
	
}
void heap_sort(int a[],int n)
{
	int i,b[n],x;
	for(i=n;i>=1;i--)
	{	
		max_heap(a,i);
		a[i]=(a[i]+a[1])-(a[1]=a[i]);
		b[i]=a[i];
		a[i]='\0';
	}
	printf("The sorted array::\n");
	for(i=1;i<=n;i++)
	printf("%d\t",b[i]);
}
int main(void)
{
	int *a,n,i;
	printf("Enter the size of array::");
	scanf("%d",&n);
	a=(int *)malloc(sizeof(int));
	printf("Enter the elements::\n");
	for(i=1;i<=n;i++)
	scanf("%d",(a+i));
	max_heap(a,n);
	heap_sort(a,n);
	return 0;	
}







