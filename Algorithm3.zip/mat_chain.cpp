#include<stdio.h>
#include<limits.h>
int n;
int m[10][10],s[10][10];
int para(int i,int j)
{
	if(i==j)
	{
		//printf(" %d %d\ n",i,j);
		printf("A%d",i);
	}
	else
	{	printf("(");
		para(i,s[i][j]);
		//printf("%d %d-%d\n",i,j,s[i][j]);
		para(s[i][j]+1,j);
		//printf("%d %d-%d\n",i,j,s[i][j]);
		printf(")");
	}
}
int max(int p[])
{
	int i,j,k,y,q,u;
	for(i=1;i<=n;i++)
	{
		m[i][i]=0;
	}
	for(y=2;y<=n;y++)
	{
		for(i=1;i<=n-y+1;i++)
		{
			j=i+y-1;
			m[i][j]=INT_MAX;
			for(k=i;k<j;k++)
			{
				q=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];
				if(m[i][j]>q)
				{
					m[i][j]=q;
					s[i][j]=k;
				}
			}
			
		}
	}
}
main()
{
	int l,p[10],i,j;
	scanf("%d",&n);
	for(i=0;i<=n;i++)
	{
		scanf("%d",&p[i]);
	}
	max(p);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(i<j)
			{
			printf("%d\t",m[i][j]);}
		}
		printf("\n");
	}
	printf("   ");
	for(j=2;j<=n;j++)
		{
		//	if(i<j)
			{
			printf("%d\t",j);}
		}
		printf("\n");
	
		for(i=1;i<=n;i++)
	{
		printf("%d-> ",i);
		for(j=1;j<=n;j++)
		{	
			if(i<j)
			{
			
			printf("%d\t",s[i][j]);}
		}
		printf("\n");
	}
//	for(i=1;i<=n;i++)
	{
		//for(j=1;j<=n;j++)
		{
			para(1,6);
		}
	}
}




