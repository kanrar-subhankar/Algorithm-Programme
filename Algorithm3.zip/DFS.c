#include<stdio.h>
#include<stdlib.h>
#define NIL -1
int nov,**a,*d,*p,*f;
int time=0;
char *color;
void file()
{
	int i,j;
	FILE *fp;
	fp=fopen("graph.txt","r");
	if(fp==NULL)
		printf("\nFile Does Not Exist!!\n");
	else
	{
		fscanf(fp,"%d",&nov);
		
		a=(int **) malloc(nov*sizeof(int*));
		for(i=0;i<nov;i++)
			a[i]=(int *)malloc(nov*sizeof(int));
		for(i=0;i<nov;i++)
			for(j=0;j<nov;j++)
				fscanf(fp,"%d",&a[i][j]);
	}
}
void dfs_visit(int u)
{
	int v;
	color[u]='G';
	++time;
	d[u]=time;
	for(v=0;v<nov;v++)
		if(a[u][v]==1)
			if(color[v]=='W')
			{
				p[v]=u;
				dfs_visit(v);
			}
	color[u]='B';
	f[u]=++time;
}
void dfs(int s)
{
	int u;
	for(u=0;u<nov;u++)
	{
		color[u]='W';
		p[u]=NIL;
	}
	color[s]='G';
	p[s]=NIL;
	time=0;
	dfs_visit(s);
	for(u=0;u<nov;u++)
		if(color[u]=='W')
			dfs_visit(u);
}
int input()
{
	int s;
	printf("\nEnter the Source Node No. : ");
	scanf("%d",&s);
	color=(char *) malloc(nov*sizeof(char));
	d=(int *) malloc(nov*sizeof(int));
	p=(int *) malloc(nov*sizeof(int));
	f=(int *) malloc(nov*sizeof(int));
	return s;
}
void main()
{
	int s,i;
	file();
	s=input();
	dfs(s);
	for(i=0;i<nov;i++)
		printf("\nParent of %d : %d ",i,p[i]);
	printf("\n");
}
