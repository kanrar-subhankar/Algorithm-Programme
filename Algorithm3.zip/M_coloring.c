#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int x[100],m,n,a[100][100];
void input()
{
	FILE *fp;
	int i,j;
	fp=fopen("color.txt","r");
	fscanf(fp,"%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
			fscanf(fp,"%d",&a[i][j]);
	}
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++)
		printf("%d  ",a[i][j]);
		printf("\n");
	}
}

void NextValue(int k)
{
	int j;
	do{
		x[k]=(x[k]+1)%(m+1);
		if(x[k]==0)
		return;
		for(j=1;j<=n;j++)
		{
			if((a[k][j]!=0) && (x[k]==x[j]))
			break;
		}
		if(j==n+1)
		return;
	  }while(1);
}

void M_coloring(int k)
{
	int i;
	do{
		NextValue(k);
		if(x[k]==0)
		return;
		if(k==n)
		{
			for(i=1;i<=n;i++)
			printf("%d ",x[i]);
			printf("\n");
		}
		else
		M_coloring(k+1);
	}while(1);
}

	
int main(void)
{
	int k;
	input();
	printf("Enter the no of color\n");
	scanf("%d",&m);
	k=1;
	M_coloring(k);
}
