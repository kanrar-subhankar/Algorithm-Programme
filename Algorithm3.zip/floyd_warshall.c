#include<stdio.h>
int p[100][100],d[100][100],n;
void input()
{
	int i,j;
	FILE *fp;
	fp=fopen("floyd.txt","r");
	if(fp==NULL)
		printf("\nFile Does Not Exist!!\n");
	else
	{
		fscanf(fp,"%d",&n);
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				fscanf(fp,"%d",&d[i][j]);
	}
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++)
		printf("%d  ",d[i][j]);
		printf("\n");
	}
}
void warshall()
{
	int i,j,k;
	for(k=1;k<=n;k++)
	{
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=n;j++)
            {
                if((d[i][k]+d[k][j])<d[i][j])
				{
					d[i][j]=d[i][k]+d[k][j];
					p[i][j]=p[k][j];
				}
			}
		}
	}
}
void shortest_path(int src,int des)
{
	if(src==des)
		printf("%d-->",src);
	else if(p[src][des]==-1)
		printf("No path from %d to %d",src,des);
	else {
		shortest_path(src,p[src][des]);
		printf("%d-->",des);
	}
}

int main(void)
{
	int s,ds,i,j;
	printf("The graph-->\n");
	input();
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(i==j || d[i][j]==9999)
			p[i][j]=-1;
			else 
			p[i][j]=i;
		}
	}
	printf("Enter the source vertex::");
	scanf("%d",&s);
	printf("Enter the destination point::");
	scanf("%d",&ds);
	warshall();
	shortest_path(s,ds);
}

