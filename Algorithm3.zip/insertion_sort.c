#include<stdio.h>
void sort(int a[],int n)
{
	int i,j,key;
	for(i=1;i<n;i++)
	{
		key=a[i];
		j=i-1;
		while(j>=0 && a[j]>key)
		{
			a[j+1]=a[j];
			j=j-1;
		}
		a[j+1]=key;
		for(j=0;j<n;j++)
			printf("%d\t",a[j]);
		printf("\n");
	}
}
int main(void)
{
	int n,i,a[100];
	printf("Enter the array size::");
	scanf("%d",&n);
	printf("Enter the array elements::\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	sort(a,n);
	printf("The sorted array\n");
	for(i=0;i<n;i++)
	printf("%d\t",a[i]);
}
	
	
