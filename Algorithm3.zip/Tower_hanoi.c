#include<stdio.h>
void toh(int n,char s,char t,char d)
{
	if(n>=1){
	toh(n-1,s,d,t);
	printf("move %d from %c to %c\n",n,s,d);
	toh(n-1,t,s,d);
	}
}

int main(void){
	int n;
	char s,t,d;
	printf("Enter the no:\t");
	scanf("%d",&n);
	toh(n,'s','t','d');
	return 0;
}
