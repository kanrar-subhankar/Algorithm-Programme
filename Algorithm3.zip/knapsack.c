#include<stdio.h>
#include<stdlib.h>
typedef struct pqr
{
	float p;
	float w;
}obj;
int no,m;
double x[10];
obj o[10];
void sort()
{
	int i,j;
	obj t;
	for(j=1;j<=no;j++)
	{
		for(i=1;i<=no-j;i++)
		{
			if((o[i].p/o[i].w)<(o[i+1].p/o[i+1].w))
			{
				t=o[i];
				o[i]=o[i+1];
				o[i+1]=t;
			}
		}
	}
}
void main()
{
	int i,j;
	float u,profit=0.0;
	FILE *fp;
	fp=fopen("knap.txt","r");
	if(fp==NULL)
	{
		printf("File is empty");
		exit(0);
	}
	else
	{
		fscanf(fp,"%d",&no);
		fscanf(fp,"%d",&m);
		for(j=1;j<=no;j++)
		{
			fscanf(fp,"%f",&o[j].p);
		}
		for(j=1;j<=no;j++)
		{
			fscanf(fp,"%f",&o[j].w);
		}
	}

	sort();
	for(i=1;i<=no;i++)
	printf("p: %.2f \t w: %.2f \n",o[i].p,o[i].w);
	for(i=1;i<=no;i++)
	x[i]=0.0;
	u=m;
	for(i=1;i<=no;i++)
	{
		if(u<o[i].w)
		break;
		x[i]=1.0;
		u=u-o[i].w;
	}
	if(i<=no)
	x[i]=u/o[i].w;
	for(i=1;i<=no;i++)
	{
		profit+=x[i]*o[i].p;
	}
	printf("\nThe net profit is:%.2f \n:",profit);
	//getch();
}
