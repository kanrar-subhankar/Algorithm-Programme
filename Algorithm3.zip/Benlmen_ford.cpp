#include<stdio.h>
#include<limits.h>
int v,n,dist[100],p[100];
void bm(int cost[][100])
{
	int i,j;
	for(i=1;i<=n;i++)
	{
		dist[i]=INT_MAX;
		p[i]=0;
	}
	dist[v]=0;
	for(i=1;i<n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(dist[i]+cost[i][j]<dist[j] && cost[i][j]!=INT_MAX )
			{
				dist[j]=dist[i]+cost[i][j];
				p[j]=i;
			}
		}
	}
	/*for(i=1;i<n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(dist[i]+cost[i][j]<dist[j] && cost[i][j]!=INT_MAX )
			{
				printf("Graph contains a negative weight cycle\n");
				return 0;
			}
		}
	}*/
}
main()
{
	int cost[100][100],i,j,k,l;
	FILE *po;
	po=fopen("path2.txt","r");
	fscanf(po,"%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			fscanf(po,"%d",&k);
			if(k==0)
			{
				cost[i][j]=INT_MAX;
			}
			else
			{
				cost[i][j]=k;
			}
		}
	}
	printf("Enter the Source vertex");
	scanf("%d",&v);
	bm(cost);
	for(i=1;i<=n;i++)
	{
		printf("%d -> %d -> p %d\n",i,dist[i],p[i]);
	}
}


